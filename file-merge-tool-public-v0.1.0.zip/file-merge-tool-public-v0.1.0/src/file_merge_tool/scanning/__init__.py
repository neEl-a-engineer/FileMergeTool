"""Shared scanning utilities."""

