from __future__ import annotations

from pathlib import Path
from typing import Any

from file_merge_tool.domain.artifact import (
    ArtifactSummary,
    SkippedItem,
    WarningItem,
    build_artifact_header,
    model_to_dict,
)
from file_merge_tool.application.output_files import merge_output_path
from file_merge_tool.application.source_target_reporting import (
    build_target_level_file_results,
    build_target_level_skipped_items,
)
from file_merge_tool.domain.config import MergeRequest
from file_merge_tool.domain.extension_selection import is_extension_selected
from file_merge_tool.domain.result import FileResult, MergeResult
from file_merge_tool.domain.rule_matching import matched_literal_substrings, matched_regex_patterns
from file_merge_tool.domain.sensitivity import SENSITIVE_MARKERS
from file_merge_tool.extractors.image_extractor import extract_image_file, is_image_file
from file_merge_tool.scanning.source_targets import flatten_scanned_items, scan_source_targets
from file_merge_tool.writers.image_html_writer import write_image_html_report
from file_merge_tool.writers.image_powerpoint_writer import write_image_powerpoint


def merge_image(request: MergeRequest) -> MergeResult:
    formats = request.image_output_formats or ("pptx",)
    unsupported = [fmt for fmt in formats if fmt not in {"html", "pptx"}]
    if unsupported:
        raise NotImplementedError(
            f"Unsupported image output format: {', '.join(unsupported)}"
        )

    target_scans = scan_source_targets(request.source_targets or (request.root_path,), request.exclude)
    scanned_items = flatten_scanned_items(target_scans)
    normal_items: list[dict[str, Any]] = []
    sensitive_items: list[dict[str, Any]] = []
    skipped_items: list[SkippedItem] = build_target_level_skipped_items(target_scans)
    warnings: list[WarningItem] = []
    file_results: list[FileResult] = build_target_level_file_results(target_scans)
    skipped_count = len(skipped_items)
    error_skipped_count = 0

    markers = _sensitivity_markers(request)

    for item in scanned_items:
        if item.kind != "file":
            if item.excluded:
                skipped_count += 1
                skipped_items.append(_skipped_item(item.relative_path, item.kind, item.excluded_reason or "skipped", item.source_target_path, item.source_target_kind, item.absolute_path, item.link_target))
                file_results.append(
                    FileResult(
                        relative_path=item.relative_path,
                        source_path=str(item.absolute_path),
                        source_target_path=item.source_target_path,
                        source_target_kind=item.source_target_kind,
                        status="skipped",
                        skip_reason=item.excluded_reason or "skipped",
                        details="The path matched an exclusion rule during traversal.",
                    )
                )
            continue

        if item.excluded:
            skipped_count += 1
            skipped_items.append(_skipped_item(item.relative_path, item.kind, item.excluded_reason or "excluded", item.source_target_path, item.source_target_kind, item.absolute_path, item.link_target))
            file_results.append(
                FileResult(
                    relative_path=item.relative_path,
                    source_path=str(item.absolute_path),
                    source_target_path=item.source_target_path,
                    source_target_kind=item.source_target_kind,
                    status="skipped",
                    skip_reason=item.excluded_reason or "excluded",
                    details="The file matched an exclusion rule.",
                )
            )
            continue

        if not is_extension_selected(
            item.absolute_path,
            selected_extensions=request.selected_extensions,
            additional_extensions=request.additional_extensions,
            kind=request.kind or "image-merge",
        ):
            skipped_count += 1
            skipped_items.append(_skipped_item(item.relative_path, item.kind, "extension_not_selected", item.source_target_path, item.source_target_kind, item.absolute_path, None))
            file_results.append(
                FileResult(
                    relative_path=item.relative_path,
                    source_path=str(item.absolute_path),
                    source_target_path=item.source_target_path,
                    source_target_kind=item.source_target_kind,
                    status="skipped",
                    skip_reason="extension_not_selected",
                    details="The file extension is not selected for this merge run.",
                )
            )
            continue

        if not is_image_file(item.absolute_path):
            skipped_count += 1
            skipped_items.append(_skipped_item(item.relative_path, item.kind, "reader_not_available", item.source_target_path, item.source_target_kind, item.absolute_path, None))
            file_results.append(
                FileResult(
                    relative_path=item.relative_path,
                    source_path=str(item.absolute_path),
                    source_target_path=item.source_target_path,
                    source_target_kind=item.source_target_kind,
                    status="skipped",
                    skip_reason="reader_not_available",
                    details="The file extension is selected, but no image reader is available for it.",
                )
            )
            continue

        try:
            extracted = extract_image_file(item.absolute_path)
        except Exception as exc:  # noqa: BLE001
            skipped_count += 1
            error_skipped_count += 1
            skipped_items.append(_skipped_item(item.relative_path, item.kind, "read_error", item.source_target_path, item.source_target_kind, item.absolute_path, None))
            warnings.append(
                WarningItem(
                    relative_path=item.relative_path,
                    reason="read_error",
                    message="Skipped because the image file could not be read.",
                    source_target_path=item.source_target_path,
                    source_target_kind=item.source_target_kind,
                    exception_type=exc.__class__.__name__,
                )
            )
            file_results.append(
                FileResult(
                    relative_path=item.relative_path,
                    source_path=str(item.absolute_path),
                    source_target_path=item.source_target_path,
                    source_target_kind=item.source_target_kind,
                    status="error",
                    skip_reason="read_error",
                    exception_type=exc.__class__.__name__,
                    message="The image file could not be read.",
                    details=str(exc),
                )
            )
            continue

        matched_markers = _matched_markers([str(item.absolute_path)], markers, request.sensitivity_patterns)
        image_item = {
            "id": f"item-{len(normal_items) + len(sensitive_items) + 1:04d}",
            "absolute_path": str(item.absolute_path),
            "relative_path": item.relative_path,
            "relative_path_from_target": item.relative_path_from_target,
            "source_target_path": item.source_target_path,
            "source_target_kind": item.source_target_kind,
            "modified_at": item.modified_at,
            "mime_type": extracted.mime_type,
            "width": extracted.width,
            "height": extracted.height,
            "file_size_bytes": extracted.file_size_bytes,
            "data_uri": extracted.data_uri,
            "sensitivity": {
                "classified": bool(matched_markers),
                "matched_markers": matched_markers,
            },
        }
        if matched_markers:
            sensitive_items.append(image_item)
            file_results.append(
                FileResult(
                    relative_path=item.relative_path,
                    source_path=str(item.absolute_path),
                    source_target_path=item.source_target_path,
                    source_target_kind=item.source_target_kind,
                    status="merged",
                    classification="confidential",
                )
            )
        else:
            normal_items.append(image_item)
            file_results.append(
                FileResult(
                    relative_path=item.relative_path,
                    source_path=str(item.absolute_path),
                    source_target_path=item.source_target_path,
                    source_target_kind=item.source_target_kind,
                    status="merged",
                    classification="normal",
                )
            )

    output_stem = _output_stem(request)
    output_paths: list[Path] = []
    if "html" in formats:
        output_paths.append(
            _write_html(
                request=request,
                output_path=merge_output_path(
                    request,
                    extension=".html",
                    default_name=output_stem,
                ),
                classification="normal",
                items=normal_items,
                skipped_items=skipped_items,
                warnings=warnings,
                skipped_count=skipped_count,
                error_skipped_count=error_skipped_count,
            )
        )
        output_paths.append(
            _write_html(
                request=request,
                output_path=merge_output_path(
                    request,
                    extension=".html",
                    default_name=output_stem,
                    classification="sensitive",
                ),
                classification="sensitive",
                items=sensitive_items,
                skipped_items=skipped_items,
                warnings=warnings,
                skipped_count=skipped_count,
                error_skipped_count=error_skipped_count,
            )
        )

    if "pptx" in formats:
        output_paths.append(
            _write_pptx(
                request=request,
                output_path=merge_output_path(
                    request,
                    extension=".pptx",
                    default_name=output_stem,
                ),
                classification="normal",
                items=normal_items,
                skipped_items=skipped_items,
                warnings=warnings,
                skipped_count=skipped_count,
                error_skipped_count=error_skipped_count,
            )
        )
        output_paths.append(
            _write_pptx(
                request=request,
                output_path=merge_output_path(
                    request,
                    extension=".pptx",
                    default_name=output_stem,
                    classification="sensitive",
                ),
                classification="sensitive",
                items=sensitive_items,
                skipped_items=skipped_items,
                warnings=warnings,
                skipped_count=skipped_count,
                error_skipped_count=error_skipped_count,
            )
        )

    return MergeResult(
        output_paths=tuple(output_paths),
        item_count=len(normal_items) + len(sensitive_items),
        skipped_count=skipped_count,
        excluded_count=sum(1 for item in scanned_items if item.excluded),
        error_skipped_count=error_skipped_count,
        warnings=tuple(f"{item.relative_path}: {item.reason}" for item in warnings),
        file_results=tuple(file_results),
    )


def _write_html(
    *,
    request: MergeRequest,
    output_path: Path,
    classification: str,
    items: list[dict[str, Any]],
    skipped_items: list[SkippedItem],
    warnings: list[WarningItem],
    skipped_count: int,
    error_skipped_count: int,
) -> Path:
    summary = ArtifactSummary(
        item_count=len(items),
        skipped_count=skipped_count,
        error_skipped_count=error_skipped_count,
        warning_count=len(warnings),
    ).dict()
    header = build_artifact_header(
        request,
        schema_name="file-merge-tool/image-html-report/v1",
        kind=request.kind or "image-merge",
        classification=classification,
    )
    return write_image_html_report(
        output_path,
        title=f"Image Merge Report ({classification})",
        header=header,
        summary=summary,
        items=items,
        skipped_items=[model_to_dict(item, exclude_none=True) for item in skipped_items],
        warnings=[model_to_dict(item, exclude_none=True) for item in warnings],
    )


def _write_pptx(
    *,
    request: MergeRequest,
    output_path: Path,
    classification: str,
    items: list[dict[str, Any]],
    skipped_items: list[SkippedItem],
    warnings: list[WarningItem],
    skipped_count: int,
    error_skipped_count: int,
) -> Path:
    summary = ArtifactSummary(
        item_count=len(items),
        skipped_count=skipped_count,
        error_skipped_count=error_skipped_count,
        warning_count=len(warnings),
    ).dict()
    header = build_artifact_header(
        request,
        schema_name="file-merge-tool/image-pptx-merge/v1",
        kind=request.kind or "image-merge",
        classification=classification,
    )
    return write_image_powerpoint(
        output_path,
        title=f"Image Merge ({classification})",
        header=header,
        summary=summary,
        items=items,
        skipped_items=[model_to_dict(item, exclude_none=True) for item in skipped_items],
        warnings=[model_to_dict(item, exclude_none=True) for item in warnings],
    )


def _output_stem(request: MergeRequest) -> str:
    if request.output_folder_name:
        return request.output_folder_name
    if request.output_stem:
        return request.output_stem
    return Path(request.output_name).stem or "images"


def _sensitivity_markers(request: MergeRequest) -> tuple[str, ...]:
    return tuple(dict.fromkeys((*SENSITIVE_MARKERS, *request.sensitivity_markers)))


def _matched_markers(
    haystacks: list[str],
    markers: tuple[str, ...],
    regex_patterns: tuple[str, ...],
) -> list[str]:
    return [
        *matched_literal_substrings(haystacks, markers),
        *matched_regex_patterns(haystacks, regex_patterns),
    ]


def _skipped_item(
    relative_path: str,
    kind: str,
    reason: str,
    source_target_path: str,
    source_target_kind: str,
    absolute_path: Path,
    link_target: str | None,
) -> SkippedItem:
    return SkippedItem(
        relative_path=relative_path,
        kind=kind,
        reason=reason,
        source_target_path=source_target_path,
        source_target_kind=source_target_kind,
        absolute_path=str(absolute_path),
        link_target=link_target,
    )
