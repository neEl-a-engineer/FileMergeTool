from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field

from file_merge_tool.domain.config import MergeRequest
from file_merge_tool.domain.sensitivity import SENSITIVE_MARKERS


TRAVERSAL_ORDER = "files-first-depth-first-name-asc"


class ExcludeInfo(BaseModel):
    folders: list[str] = Field(default_factory=list)
    extensions: list[str] = Field(default_factory=list)
    folder_patterns: list[str] = Field(default_factory=list)
    file_names: list[str] = Field(default_factory=list)
    file_patterns: list[str] = Field(default_factory=list)


class CollectionInfo(BaseModel):
    selected_extensions: list[str] = Field(default_factory=list)
    additional_extensions: list[str] = Field(default_factory=list)
    effective_extensions: list[str] = Field(default_factory=list)


class TraversalInfo(BaseModel):
    order: str = TRAVERSAL_ORDER
    follow_symlinks: bool = False


class SensitivityInfo(BaseModel):
    default_markers: list[str] = Field(default_factory=list)
    additional_markers: list[str] = Field(default_factory=list)
    regex_patterns: list[str] = Field(default_factory=list)
    split_outputs: bool = True


class ArtifactHeader(BaseModel):
    job_id: str | None = None
    tool: str = "file-merge-tool"
    schema_name: str = Field(alias="schema")
    kind: str
    classification: str = "normal"
    generated_at: str
    source_root: str
    source_targets: list[str] = Field(default_factory=list)
    setting_name: str | None = None
    traversal: TraversalInfo = Field(default_factory=TraversalInfo)
    collection: CollectionInfo
    exclude: ExcludeInfo
    sensitivity: SensitivityInfo


class ArtifactSummary(BaseModel):
    item_count: int = 0
    excluded_count: int = 0
    skipped_count: int = 0
    error_skipped_count: int = 0
    warning_count: int = 0


class WarningItem(BaseModel):
    relative_path: str
    reason: str
    message: str
    source_target_path: str | None = None
    source_target_kind: str | None = None
    exception_type: str | None = None


class SkippedItem(BaseModel):
    relative_path: str
    kind: str
    reason: str
    source_target_path: str | None = None
    source_target_kind: str | None = None
    absolute_path: str | None = None
    link_target: str | None = None


def build_artifact_header(
    request: MergeRequest,
    *,
    schema_name: str,
    kind: str,
    classification: str = "normal",
) -> dict[str, Any]:
    from file_merge_tool.domain.extension_selection import effective_selected_extensions

    default_markers = list(SENSITIVE_MARKERS)
    additional_markers = [
        marker for marker in request.sensitivity_markers if marker not in default_markers
    ]
    header = ArtifactHeader(
        job_id=request.job_id,
        schema=schema_name,
        kind=kind,
        classification=classification,
        generated_at=datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        source_root=str(request.root_path.resolve()),
        source_targets=[str(path) for path in request.source_targets or (request.root_path,)],
        setting_name=request.setting_name,
        collection=CollectionInfo(
            selected_extensions=list(request.selected_extensions),
            additional_extensions=list(request.additional_extensions),
            effective_extensions=list(
                effective_selected_extensions(
                    request.selected_extensions,
                    request.additional_extensions,
                    kind=request.kind,
                )
            ),
        ),
        exclude=ExcludeInfo(
            folders=list(request.exclude.folder_names),
            extensions=list(request.exclude.extensions),
            folder_patterns=list(request.exclude.folder_patterns),
            file_names=list(request.exclude.file_names),
            file_patterns=list(request.exclude.file_patterns),
        ),
        sensitivity=SensitivityInfo(
            default_markers=default_markers,
            additional_markers=list(additional_markers),
            regex_patterns=list(request.sensitivity_patterns),
        ),
    )
    return model_to_dict(header, by_alias=True, exclude_none=True)


def model_to_dict(model: BaseModel, **kwargs: Any) -> dict[str, Any]:
    if hasattr(model, "model_dump"):
        return model.model_dump(**kwargs)  # type: ignore[attr-defined]
    return model.dict(**kwargs)
