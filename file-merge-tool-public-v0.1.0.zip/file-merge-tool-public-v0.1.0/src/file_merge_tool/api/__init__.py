"""FastAPI interface."""

